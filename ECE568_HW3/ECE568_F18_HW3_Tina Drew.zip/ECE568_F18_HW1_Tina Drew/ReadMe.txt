


The program is used to do baysien curve fitting with gaussian distribution
In in order to run the program:

1) Install python 3.6.4
2) Install the these modules as well:
	(scipy, matplotlib)
3) Double click the "CurveFit.py" file
4) The file will run with the data set already included

Please note that I was not able to produce a plot of the full curve fitting algorithm. 
